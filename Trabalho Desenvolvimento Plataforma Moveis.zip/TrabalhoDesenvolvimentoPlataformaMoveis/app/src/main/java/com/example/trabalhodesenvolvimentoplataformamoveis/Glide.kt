package com.example.trabalhodesenvolvimentoplataformamoveis;

class Glide {

}
