package com.example.trabalhodesenvolvimentoplataformamoveis

import android.os.Bundle
import androidx.activity.ComponentActivity

class EditarArteActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.editar_arte)

    }
}